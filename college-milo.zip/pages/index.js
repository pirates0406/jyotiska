import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageCircle } from "lucide-react";

export default function CollegeMilo() {
  const googleFormUrl =
    "https://docs.google.com/forms/d/e/1FAIpQLSfDbR6mtGRvjnZjqZpqQq9T8YSYnC6otHvxPIjIaqQSlVH8pw/viewform?usp=dialog";

  const courses = ["Engineering", "Medical", "BCA", "BBA", "B.Com", "MBA"];

  return (
    <div className="bg-gray-50 min-h-screen p-4 sm:p-6 max-w-6xl mx-auto font-sans">
      <header className="text-center mb-10 sm:mb-12">
        <h1 className="text-3xl sm:text-5xl font-extrabold text-blue-800 tracking-wide mb-2 sm:mb-3">College Milo</h1>
        <p className="text-base sm:text-xl text-gray-600 max-w-2xl mx-auto">
          Discover top private colleges in every Indian state for Commerce and Science students – Engineering, Medical, BCA, BBA, B.Com, and MBA.
        </p>
      </header>

      <section className="mb-12 sm:mb-14 text-center">
        <h2 className="text-2xl sm:text-3xl font-bold text-blue-700 mb-4 sm:mb-6">Courses We Help You With</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4 text-sm sm:text-lg text-gray-700">
          {courses.map((course, index) => (
            <span key={index} className="bg-white p-2 sm:p-3 rounded-xl shadow">
              {course}
            </span>
          ))}
        </div>
      </section>

      <section className="mb-12 sm:mb-14 text-center">
        <h2 className="text-2xl sm:text-3xl font-bold text-blue-700 mb-3 sm:mb-4">Get in Touch</h2>
        <p className="text-base sm:text-lg text-gray-600 mb-2 sm:mb-3">Have questions? Call us:</p>
        <div className="text-base sm:text-lg font-medium text-gray-800 space-y-1">
          <div>📞 9330402032</div>
          <div>📞 9088642992</div>
        </div>
      </section>

      <section className="mb-16 sm:mb-20">
        <h2 className="text-2xl sm:text-3xl font-bold text-blue-700 mb-4 sm:mb-6 text-center">Student Inquiry Form</h2>
        <Card className="shadow-xl rounded-2xl">
          <CardContent className="space-y-4 pt-6 pb-6 px-4 sm:px-8">
            <p className="text-gray-700 text-base sm:text-lg">
              Click the button below to fill out your details. Our counselors will get in touch with you soon.
            </p>
            <div className="flex justify-center">
              <a
                href={googleFormUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="px-6 sm:px-8 py-2 sm:py-3 text-base sm:text-lg rounded-xl">Go to Form</Button>
              </a>
            </div>
          </CardContent>
        </Card>
      </section>

      <a
        href="https://wa.me/919088642992"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 bg-green-500 hover:bg-green-600 text-white rounded-full p-3 sm:p-4 shadow-lg flex items-center z-50"
        title="Chat on WhatsApp"
      >
        <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5 mr-1 sm:mr-2" />
        <span className="hidden sm:inline">WhatsApp Us</span>
      </a>
    </div>
  );
}
